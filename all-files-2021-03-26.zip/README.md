2020-03-26


julia-in-sage
=============

Julia Key Agreement (JKA) implemented in SageMath 9.2.
See the worksheet (julia.ipynb) for more information.

If you do not have SageMath installed, download it from:
[www.sagemath.org](https://www.sagemath.org/).

The code is in the public domain. Use it as you wish.
